using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CommonMove 
{
    Common_Methods common_Methods = new Common_Methods();
    private int movementRange = 8;
    public void BishopMoves(Vector3 spritePosition)
    {

        Vector3[] directions = { Vector3.left, Vector3.right };

        foreach (Vector3 direction in directions)
        {
            for (int i = 1; i <= movementRange; i++)
            {
                Vector3 newPosition1 = spritePosition + direction * i + Vector3.up * i;

                if (common_Methods.GetSpriteAtPosition(newPosition1) == "Black")
                {
                    break;
                }

                common_Methods.HighlightPlace(newPosition1);

            }
        }
        foreach (Vector3 direction in directions)
        {
            for (int i = 1; i <= movementRange; i++)
            {
                Vector3 newPosition2 = spritePosition + direction * i + Vector3.down * i;

                if (common_Methods.GetSpriteAtPosition(newPosition2) == "Black")
                {
                    break;
                }

                common_Methods.HighlightPlace(newPosition2);

            }
        }
    }
    public void RookMoves(Vector3 spritePosition)
    {
        Vector3[] directions = { Vector3.up, Vector3.down, Vector3.left, Vector3.right };

        foreach (Vector3 direction in directions)
        {
            for (int i = 1; i <= movementRange; i++)
            {
                Vector3 newPosition = spritePosition + direction * i;

                if (common_Methods.GetSpriteAtPosition(newPosition) == "Black")
                {
                    break;
                }

                common_Methods.HighlightPlace(newPosition);
            }
        }
    }
}
