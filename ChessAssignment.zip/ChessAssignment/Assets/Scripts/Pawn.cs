using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pawn : MonoBehaviour
{
    public int flag = 0;
    Common_Methods common_Methods = new Common_Methods();
    private int movementRange = 3;
    private int row = 0;
    private int col = 0;
    private void OnMouseDown()
    {
        Vector3 spritePosition = transform.position;
        (row, col) = common_Methods.PositionToBoardIndex(spritePosition);
        movementRange = row == 1 ? 2 : 1;
        if (flag == 0)
        {
            for (int i = 0; i < movementRange; i++)
            {
                if (common_Methods.GetSpriteAtPosition(new Vector3(spritePosition.x, spritePosition.y + i + 1, spritePosition.z)) == "Black")
                {
                    break;
                }
                common_Methods.HighlightPlace(new Vector3(spritePosition.x, spritePosition.y + i + 1, spritePosition.z));

            }
            flag = 1;
        }
        else
        {
            ChessBoardPlacementHandler.Instance.ClearHighlights();
            flag = 0;
        }





    }
}






















/*for (int i = 0; i < movementRange; i++)
        {
            (GameObject piece, string piecename) = GetSpriteAtPosition(new Vector3(spritePosition.x, spritePosition.y + i + 1, spritePosition.z));
            if (piecename == "Green" || piece == null)
            {
                continue;
            }
            else
            {
                movementRange = i;
                break;
            }

        }


        // Duplicate or destroy prefabs based on existing sprites
        for (int i = 0; i < movementRange; i++)
        {
            duplicatePosition[i] = new Vector3(spritePosition.x, spritePosition.y + i + 1, spritePosition.z);
            if (spritePosition.y + i + 1 <= 3.5f)
            {
                (existingSprite[i], existingSpriteTag[i]) = GetSpriteAtPosition(duplicatePosition[i]);
                if (existingSprite[i] == null)
                {
                    DuplicatePrefab(duplicatePosition[i]);
                }
                else
                {
                    Destroy(existingSprite[i]);
                }
            }
        }*/