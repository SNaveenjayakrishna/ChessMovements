using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static Unity.IO.LowLevel.Unsafe.AsyncReadManagerMetrics;

public class Common_Methods
{


    public (int, int) PositionToBoardIndex(Vector3 position)
    {
        int row = Mathf.RoundToInt(position.y + 3.5f);
        int col = Mathf.RoundToInt(position.x + 3.5f);
        return (row, col);
    }
    public string GetSpriteAtPosition(Vector3 position)
    {
        Collider2D collider = Physics2D.OverlapPoint(position);
        return collider != null ? (collider.tag) : (null);
    }
    public void HighlightPlace(Vector3 direction)
    {


        (int newRow, int newCol) = PositionToBoardIndex(direction);


        if (ChessBoardPlacementHandler.Instance.GetTile(newRow, newCol))
        {
            string name = GetSpriteAtPosition(direction);
            if (name != "Black" && name != "Green")
            {

                ChessBoardPlacementHandler.Instance.Highlight(newRow, newCol);


            }
        }


    }
}
