using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Knight : MonoBehaviour
{
    public int flag = 0;


    Common_Methods common_Methods = new Common_Methods();



    private void OnMouseDown()
    {
        Vector3 spritePosition = transform.position;
        if (flag == 0)
        {
            common_Methods.HighlightPlace(spritePosition + new Vector3(-1, 2, 0));
            common_Methods.HighlightPlace(spritePosition + new Vector3(1, 2, 0));
            common_Methods.HighlightPlace(spritePosition + new Vector3(-2, 1, 0));
            common_Methods.HighlightPlace(spritePosition + new Vector3(2, 1, 0));
            common_Methods.HighlightPlace(spritePosition + new Vector3(-1, -2, 0));
            common_Methods.HighlightPlace(spritePosition + new Vector3(1, -2, 0));
            common_Methods.HighlightPlace(spritePosition + new Vector3(-2, -1, 0));
            common_Methods.HighlightPlace(spritePosition + new Vector3(2, -1, 0));
            flag = 1;
        }
        else
        {
            ChessBoardPlacementHandler.Instance.ClearHighlights();
            flag = 0;
        }
    }
}
