using System.Collections;
using System.Collections.Generic;
using Chess.Scripts.Core;
using UnityEngine;

public class King : MonoBehaviour
{
  
   
    public int flag = 0;
 
    Common_Methods common_Methods = new Common_Methods();

    private void Start()
    {
    }
    private void OnMouseDown()
    {
        Vector3 spritePosition = transform.position;
      
        if (flag == 0)
        {
            common_Methods.HighlightPlace(spritePosition + Vector3.right);
            common_Methods.HighlightPlace(spritePosition + Vector3.left);
            common_Methods.HighlightPlace(spritePosition + Vector3.up);
            common_Methods.HighlightPlace(spritePosition + Vector3.down);
            common_Methods.HighlightPlace(spritePosition + new Vector3(1, 1, 0));//front right
            common_Methods.HighlightPlace(spritePosition + new Vector3(-1, 1, 0));//back right
            common_Methods.HighlightPlace(spritePosition + new Vector3(-1, -1, 0));//back left
            common_Methods.HighlightPlace(spritePosition + new Vector3(1, -1, 0));//front left
            flag = 1;

        }
        else
        {
            ChessBoardPlacementHandler.Instance.ClearHighlights();
            flag = 0;
        }

    }
       
    }

























