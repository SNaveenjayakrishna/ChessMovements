using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bishop : MonoBehaviour
{
    public int flag = 0;
    CommonMove move = new CommonMove();

    private void OnMouseDown()
    {

        Vector3 spritePosition = transform.position;


        if (flag == 0)
        {

            move.BishopMoves(spritePosition);

            flag = 1;
        }
        else
        {
            ChessBoardPlacementHandler.Instance.ClearHighlights();
            flag = 0;
        }

    }

    

}

