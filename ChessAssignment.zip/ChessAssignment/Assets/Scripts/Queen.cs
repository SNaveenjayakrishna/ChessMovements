using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static Unity.IO.LowLevel.Unsafe.AsyncReadManagerMetrics;

public class Queen : MonoBehaviour
{
    public int flag = 0;
    CommonMove move = new CommonMove();
  
    private void OnMouseDown()
    {

        Vector3 spritePosition = transform.position;

        if (flag == 0)
        {

            move.BishopMoves(spritePosition);
            move.RookMoves(spritePosition);

            flag = 1;
        }
        else
        {
            ChessBoardPlacementHandler.Instance.ClearHighlights();
            flag = 0;
        }

    }
   
  

}
